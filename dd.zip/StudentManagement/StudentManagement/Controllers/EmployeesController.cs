﻿using Microsoft.AspNetCore.Mvc;
using StudentManagement.Models;
using StudentManagement.Repositories;

namespace StudentManagement.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly IRepository<Employee> _repository;

        public EmployeesController(IRepository<Employee> repository)
        {

            _repository = repository;
        }

        public async Task<IActionResult> Index()
        {
            var employees = await _repository.GetAllAsync();

            return View(employees);
        }

        public async Task<IActionResult> Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Employee employee)
        {
            await _repository.AddAsync(employee);

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Edit(int id)
        {
            var employee = await _repository.GetByIdAsync(id);

            if (employee == null)
            {
                return NotFound(id);
            }

            return View(employee);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Employee employee)
        {
            await _repository.UpdateAsync(employee);

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(int id)
        {
            var emplotee = await _repository.GetByIdAsync(id);

            if (emplotee == null)
            {
                return NotFound(id);
            }

            await _repository.DeleteAsync(emplotee);

            return RedirectToAction("Index");
        }
    }

}
