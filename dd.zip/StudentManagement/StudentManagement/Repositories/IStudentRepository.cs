﻿using StudentManagement.Models;

namespace StudentManagement.Repositories
{
        public interface IStudentRepository : IRepository<Student>
        {
            Task<Student?> GetStudentDetailsByIdAsync(int id);
        }
    
}
